define(['dojo/_base/declare', 
'jimu/BaseWidget',
'dijit/_WidgetsInTemplateMixin',
'esri/graphicsUtils',
'esri/graphic',
'dojo/store/Memory',
'esri/tasks/query',
'esri/tasks/QueryTask',
'esri/symbols/SimpleFillSymbol',
'esri/symbols/SimpleLineSymbol',
'dojo/_base/Color',
'dijit/registry',
'dijit/form/FilteringSelect',
'jimu/dijit/Message',
'dojo/on'
],
  function(declare,BaseWidget,_WidgetsInTemplateMixin,graphicsUtils,Graphic,Memory,Query,QueryTask,SimpleFillSymbol,SimpleLineSymbol,ColorDojo,registry,FilteringSelect,Message,on) {
    //To create a widget, you need to derive from BaseWidget.
    return declare([BaseWidget, _WidgetsInTemplateMixin], {
      // Custom widget code goes here
      baseClass: 'jimu-widget-CountyWidget',

      //this property is set by the framework when widget is loaded.
      name: 'County Widget',

      postCreate: function() {
        this.inherited(arguments);
		this._GetProjectList();
      },

      startup: function() {
       this.inherited(arguments);
      },
	  
	  _GetProjectList: function () {
			//Query the counties
			var item = "NAME";
			var queryTask = new QueryTask
			("https://services2.arcgis.com/rwqARsO7kmPlpMQS/ArcGIS/rest/services/MNcounties/FeatureServer/0"); //service
			var query = new Query();
			query.where = "1=1"; //query to get all counties
			query.returnGeometry = false;
			query.outFields = [ item ];
			query.orderByFields = [ item ];
			queryTask.execute(query, getStoreQueryValues);

			//Loop through and store all MN counties in dropdown box
			function getStoreQueryValues(results){
				var data = {
					identifier: 'id', //This field needs to have unique values
					label: 'name', //Name field for display.
					items: []
				};

				var storeItem = new Memory({
					data: data
				});

				var itemStr = "";
				for (var i = 0; i < results.features.length; i++) {
					if(itemStr.indexOf(results.features[i].attributes[item]) == -1){
						itemStr += "{id: '" + (i + 1) + "',name:'" + results.features[i].attributes[item] + "'},";
						storeItem.put({'id': (i + 1),'name': results.features[i].attributes[item]});
					}
				}
				if (registry.byId("MNcountylist")) {
					registry.byId("MNcountylist").reset();
					registry.byId("MNcountylist").store = storeItem;
				}
			}
		},
		
	//Function to zoom to county
	_ZoomCounty: function () {
		//Query the selected county
		var queryTask = new QueryTask("https://services2.arcgis.com/rwqARsO7kmPlpMQS/ArcGIS/rest/services/MNcounties/FeatureServer/0"); //service
		var query = new Query();
		query.where = "NAME = '" + registry.byId("MNcountylist").displayedValue + "'";	query.returnGeometry = true;
		query.outFields = ["NAME"];

		map = this.map;

		query.outSpatialReference = {
			wkid: 102100
		};
		on(queryTask, "complete", function(evt){
			zoomToResults(evt, map);
		});
		queryTask.execute(query, showSpatialResults);

		//Create graphic for zoom results
		function showSpatialResults(results){
			ClearSearchGraphics(map);
			var fieldsSelectionSymbol = new SimpleFillSymbol(SimpleFillSymbol.STYLE_SOLID,new SimpleLineSymbol(SimpleLineSymbol.STYLE_DASHDOT, new ColorDojo([255,255,0]), 6),new ColorDojo([255,255,0,0.35]));
			map.graphics.add(new Graphic(results.features[0].geometry, fieldsSelectionSymbol));
		}
		//zoom to the location of the result
		function zoomToResults(evt,map){
			var featureSet = evt || {};
			var features = featureSet.featureSet.features || [];
			if (features.length > 0) {
				var extent = graphicsUtils.graphicsExtent(features);
				if (extent) {
					map.setExtent(extent.expand(1.5), true);
				}
			}
			else {
				new Message({message: 'The county was not found on the map!',titleLabel: "County Widget Error!",autoHeight: true});
			}
		}

		//clear previous search yellow polygon
		function ClearSearchGraphics(map){
			if (map.graphics) {
				map.graphics.clear();
			}
		}
	}


    });
  });